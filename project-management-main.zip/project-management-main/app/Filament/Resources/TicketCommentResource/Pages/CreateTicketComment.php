<?php

namespace App\Filament\Resources\TicketCommentResource\Pages;

use App\Filament\Resources\TicketCommentResource;
use Filament\Resources\Pages\CreateRecord;

class CreateTicketComment extends CreateRecord
{
    protected static string $resource = TicketCommentResource::class;
}
