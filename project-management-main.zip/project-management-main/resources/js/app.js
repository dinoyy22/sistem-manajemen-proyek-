import './bootstrap';
import '../css/project-board.css';
